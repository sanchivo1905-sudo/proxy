# Luh Proxy — proyecto Android

Este proyecto contiene el código fuente de una app Android tipo panel companion, con interfaz estilo Lunar, lista de servidores guardada localmente y biblioteca/listado de archivos `.mcpack`/`.zip`.

## Crear el APK
Se necesita Android Studio o un entorno Android con SDK instalado:
1. Abrí esta carpeta como proyecto en Android Studio.
2. Esperá la sincronización de Gradle.
3. Usá `Build > Build APK(s)`.
4. El APK de depuración normalmente se genera en `app/build/outputs/apk/debug/app-debug.apk`.

Para compilar en el teléfono se puede intentar abrir el proyecto en un IDE Android que admita proyectos Gradle y tenga acceso a SDK; la configuración exacta depende de la versión.

## Límites
- Este proyecto fuente no es un APK ya compilado.
- No incluye un relay Bedrock real ejecutándose en Android.
- La biblioteca registra el nombre/tamaño del archivo seleccionado; no copia ni instala el pack en Minecraft.
- No puede importar skins PNG en Minecraft PS5.
- Los servidores se guardan en localStorage del WebView.
- No es una app oficial de Mojang/Microsoft.
